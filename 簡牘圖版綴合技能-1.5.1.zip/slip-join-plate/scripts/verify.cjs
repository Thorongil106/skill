#!/usr/bin/env node
'use strict';
const fs=require('fs'),os=require('os'),path=require('path'),assert=require('assert');
const {compose,fit,apply,pose,polygon,loadSharp}=require('./compose.cjs');
async function main(){
  const sharp=require(process.argv[2]??'sharp'),root=fs.mkdtempSync(path.join(os.tmpdir(),'slip-join-verify-'));
  const t={x:7,y:-9,scale:1.25,rotation:12};const ps=[[0,0],[10,0],[4,7],[11,8]];
  const f=fit(ps.map(p=>({point:p,target:apply(t,p)})),pose(),true);
  for(const k of Object.keys(t))assert(Math.abs(f.transform[k]-t[k])<1e-8,`fit ${k}`);
  assert(f.rms<1e-8);
  const locked=fit(ps.map(p=>({point:p,target:apply(t,p)})),pose(),false,1.25);assert(locked.rms<1e-8);
  assert.throws(()=>pose({scaleX:1}),/Unsupported/);assert.throws(()=>pose({scale:-1}),/positive/);
  assert.throws(()=>polygon([[0,0],[10,10],[0,10],[10,0]],10,10),/non-collinear|intersecting/);
  const w=16,h=20,a=Buffer.alloc(w*h*4),b=Buffer.alloc(w*h*4);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const z=(y*w+x)*4;a[z]=x*9;a[z+1]=y*9;a[z+2]=51;a[z+3]=255;b[z]=150;b[z+1]=x*4;b[z+2]=y*5;b[z+3]=255;}
  const A=path.join(root,'upper.png'),B=path.join(root,'lower.png');await sharp(a,{raw:{width:w,height:h,channels:4}}).png().toFile(A);await sharp(b,{raw:{width:w,height:h,channels:4}}).png().toFile(B);
  const originalA=fs.readFileSync(A),originalB=fs.readFileSync(B);
  const cfg={name:'test',margin:0,pixelsPerUnit:1,pieces:[{id:'A',image:A},{id:'B',image:B,transform:{y:h}}],detail:{x:0,y:17,width:16,height:6,pixelsPerUnit:2}};
  const file=path.join(root,'job.json');fs.writeFileSync(file,JSON.stringify(cfg));const result=await compose(file,path.join(root,'out'),sharp);
  const raw=await sharp(path.join(root,'out','test-transparent.png')).ensureAlpha().raw().toBuffer({resolveWithObject:true});assert.equal(raw.info.width,w);assert.equal(raw.info.height,h*2);assert.deepEqual(raw.data,Buffer.concat([a,b]),'Integer-placed source pixels changed');
  assert.deepEqual(fs.readFileSync(A),originalA);assert.deepEqual(fs.readFileSync(B),originalB);
  const svg=fs.readFileSync(path.join(root,'out','test.svg'),'utf8');const embeds=[...svg.matchAll(/base64,([^" ]+)/g)].map(m=>Buffer.from(m[1],'base64'));assert.deepEqual(embeds,[originalA,originalB],'SVG embedding changed original bytes');
  const detail=await sharp(path.join(root,'out','test-detail.png')).metadata();assert.equal(detail.width,32);assert.equal(detail.height,12);assert.equal(result.overlaps.length,0);
  // A copied job must not depend on the original device's absolute paths.
  const bundle=path.join(root,'project original'),moved=path.join(root,'新設備 moved');fs.mkdirSync(bundle);
  fs.writeFileSync(path.join(bundle,'upper.png'),originalA);fs.writeFileSync(path.join(bundle,'lower.png'),originalB);
  const portable=JSON.parse(JSON.stringify(cfg));portable.pieces[0].image='upper.png';portable.pieces[1].image='lower.png';
  portable.pieces[0].provenance='upper.source.json';
  fs.writeFileSync(path.join(bundle,'upper.source.json'),JSON.stringify({image:'upper.png',imageSha256:require('crypto').createHash('sha256').update(originalA).digest('hex')}));
  fs.writeFileSync(path.join(bundle,'job.json'),JSON.stringify(portable));fs.renameSync(bundle,moved);
  await compose(path.join(moved,'job.json'),path.join(moved,'out'),sharp);
  assert.deepEqual(await sharp(path.join(moved,'out','test-transparent.png')).raw().toBuffer(),raw.data,'Moved relative-path job differs');
  // Resolve a workspace-local module when the skill itself lives elsewhere.
  const moduleDir=path.join(moved,'node_modules','sharp');fs.mkdirSync(moduleDir,{recursive:true});
  fs.writeFileSync(path.join(moduleDir,'index.js'),'module.exports={fixture:true};');
  assert.equal(loadSharp(undefined,path.join(moved,'job.json')).fixture,true);
  cfg.pieces[1].transform.y=15;fs.writeFileSync(file,JSON.stringify(cfg));const overlapped=await compose(file,path.join(root,'overlap'),sharp);assert(overlapped.overlaps[0].estimatedAreaInCanvasUnits>0);assert(fs.existsSync(path.join(root,'overlap','test-reverse-layer-check.png')));
  assert.notDeepEqual(await sharp(path.join(root,'overlap','test.png')).raw().toBuffer(),await sharp(path.join(root,'overlap','test-reverse-layer-check.png')).raw().toBuffer());
  cfg.pieces[0].polygon=[[2,2],[14,2],[8,18]];cfg.pieces=cfg.pieces.slice(0,1);delete cfg.detail;fs.writeFileSync(file,JSON.stringify(cfg));await compose(file,path.join(root,'mask'),sharp);
  const masked=await sharp(path.join(root,'mask','test-transparent.png')).ensureAlpha().raw().toBuffer({resolveWithObject:true});const alpha=(x,y)=>masked.data[(y*masked.info.width+x)*4+3];assert.equal(alpha(0,14),0,'Outside mask should be transparent');assert.equal(alpha(6,4),255,'Inside mask should remain opaque');
  const grey=await sharp(path.join(root,'mask','test-edge-check.png')).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const rgba=(image,x,y)=>[...image.data.subarray((y*image.info.width+x)*4,(y*image.info.width+x)*4+4)];
  assert.deepEqual(rgba(grey,0,14),[128,128,128,255],'Outside mask should show grey diagnostic background');
  assert.deepEqual(rgba(grey,6,4),rgba(masked,6,4),'Grey diagnostic must retain opaque source pixels');
  // A foreground may hide a white-background halo in the composite. The isolated
  // display-layer panel must reveal it, while retaining pale material unchanged.
  const haloPixels=Buffer.alloc(12*12*4,255);
  for(let y=2;y<10;y++)for(let x=2;x<10;x++){const z=(y*12+x)*4;haloPixels[z]=180;haloPixels[z+1]=150;haloPixels[z+2]=120;}
  haloPixels.set([247,245,242,255],(4*12+4)*4);
  const H=path.join(root,'halo.png');await sharp(haloPixels,{raw:{width:12,height:12,channels:4}}).png().toFile(H);
  const originalHalo=fs.readFileSync(H);
  const haloCfg={name:'halo',margin:0,pixelsPerUnit:1,pieces:[{id:'back-layer',image:H,polygon:[[1,1],[11,1],[11,11],[1,11]]},{id:'cover-layer',image:B}],detail:{x:-1,y:-1,width:14,height:14,pixelsPerUnit:1}};
  fs.writeFileSync(file,JSON.stringify(haloCfg));await compose(file,path.join(root,'halo-before'),sharp);
  const beforeManifest=JSON.parse(fs.readFileSync(path.join(root,'halo-before','halo-manifest.json')));
  const beforeSheet=await sharp(path.join(root,'halo-before','halo-detail-edge-check.png')).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const beforePanel=beforeManifest.edgeDiagnostics.detail.panels.find(p=>p.displayLayerIds.length===1&&p.displayLayerIds[0]==='back-layer').imageRect;
  const beforeComposite=beforeManifest.edgeDiagnostics.detail.panels[0].imageRect;
  assert.deepEqual(rgba(beforeSheet,beforePanel.x+2,beforePanel.y+2),[255,255,255,255],'Isolated layer must expose retained white background');
  assert.notDeepEqual(rgba(beforeSheet,beforeComposite.x+2,beforeComposite.y+2),[255,255,255,255],'Foreground should hide the same halo in the composite fixture');
  assert.deepEqual(rgba(beforeSheet,beforePanel.x+5,beforePanel.y+5),[247,245,242,255],'Pale source material must remain unchanged');
  haloCfg.pieces[0].polygon=[[2,2],[10,2],[10,10],[2,10]];
  fs.writeFileSync(file,JSON.stringify(haloCfg));await compose(file,path.join(root,'halo-after'),sharp);
  const afterManifest=JSON.parse(fs.readFileSync(path.join(root,'halo-after','halo-manifest.json')));
  const afterSheet=await sharp(path.join(root,'halo-after','halo-detail-edge-check.png')).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  const afterPanel=afterManifest.edgeDiagnostics.detail.panels.find(p=>p.displayLayerIds.length===1&&p.displayLayerIds[0]==='back-layer').imageRect;
  assert.deepEqual(rgba(afterSheet,afterPanel.x+2,afterPanel.y+2),[128,128,128,255],'Corrected external mask should reveal grey, without recoloring source');
  assert.deepEqual(rgba(afterSheet,afterPanel.x+5,afterPanel.y+5),[247,245,242,255]);
  assert.deepEqual(fs.readFileSync(H),originalHalo);
  assert.deepEqual(beforeManifest.pieces.map(p=>p.transform),afterManifest.pieces.map(p=>p.transform),'Edge diagnostics must not alter placement');
  assert.deepEqual(await sharp(path.join(root,'halo-before','halo.png')).raw().toBuffer(),await sharp(path.join(root,'halo-after','halo.png')).raw().toBuffer(),'Occluded correction fixture should leave composite unchanged');
  assert.equal(afterManifest.edgeDiagnostics.detail.scaleLimited,false);
  assert.deepEqual(afterManifest.edgeDiagnostics.detail.view,{x:-1,y:-1,width:14,height:14});
  // Local alternating occlusion may repeat a physical fragment as display layers,
  // but every explicitly grouped layer must use the same source and whole pose.
  const copiedA=path.join(root,'upper-copy.png');fs.writeFileSync(copiedA,originalA);
  const alternating={name:'alternating',margin:0,pixelsPerUnit:1,pieces:[
    {id:'a-original',physicalPieceId:'A',image:A},
    {id:'b-original',physicalPieceId:'B',image:B,transform:{y:15}},
    {id:'a-left-face',physicalPieceId:'A',image:copiedA,polygon:[[0,15],[8,15],[8,20],[0,20]],transform:{x:0,y:0,scale:1,rotation:0}},
    {id:'b-right-face',physicalPieceId:'B',image:B,polygon:[[8,0],[16,0],[16,5],[8,5]],transform:{y:15}}
  ]};
  fs.writeFileSync(file,JSON.stringify(alternating));await compose(file,path.join(root,'alternating'),sharp);
  const alternatePixels=await sharp(path.join(root,'alternating','alternating-transparent.png')).ensureAlpha().raw().toBuffer({resolveWithObject:true});
  assert.deepEqual(rgba(alternatePixels,4,17),[36,153,51,255],'Left overlap should display A');
  assert.deepEqual(rgba(alternatePixels,12,17),[150,48,10,255],'Right overlap should display B');
  const alternateManifest=JSON.parse(fs.readFileSync(path.join(root,'alternating','alternating-manifest.json')));
  assert.deepEqual(alternateManifest.pieces.map(p=>p.physicalPieceId),['A','B','A','B']);
  assert.equal(alternateManifest.pieces[0].sha256,alternateManifest.pieces[2].sha256,'Explicit groups permit byte-identical source copies');
  for(const key of ['x','y','scale','rotation']){
    const wrong=JSON.parse(JSON.stringify(alternating));wrong.pieces[2].transform[key]+=.01;
    fs.writeFileSync(file,JSON.stringify(wrong));
    await assert.rejects(compose(file,path.join(root,'invalid-'+key),sharp),/identical resolved transform/);
    assert(!fs.existsSync(path.join(root,'invalid-'+key)),'Invalid grouping must fail before output');
  }
  const wrongSource=JSON.parse(JSON.stringify(alternating));wrongSource.pieces[2].image=B;
  fs.writeFileSync(file,JSON.stringify(wrongSource));
  await assert.rejects(compose(file,path.join(root,'invalid-source'),sharp),/identical source bytes/);
  const wrongId=JSON.parse(JSON.stringify(alternating));wrongId.pieces[2].physicalPieceId=' ';
  fs.writeFileSync(file,JSON.stringify(wrongId));
  await assert.rejects(compose(file,path.join(root,'invalid-id'),sharp),/nonempty string/);
  const ungrouped={name:'ungrouped',margin:0,pixelsPerUnit:1,pieces:[{id:'one',image:A},{id:'two',image:A,transform:{x:4}}]};
  fs.writeFileSync(file,JSON.stringify(ungrouped));await compose(file,path.join(root,'ungrouped'),sharp);
  const ungroupedManifest=JSON.parse(fs.readFileSync(path.join(root,'ungrouped','ungrouped-manifest.json')));
  assert(ungroupedManifest.pieces.every(p=>!Object.hasOwn(p,'physicalPieceId')),'Legacy jobs must not infer physical grouping from source paths');
  console.log('PASS: similarity and locked-scale fits; invalid transform/mask rejection; unchanged source hashes and SVG bytes; exact integer pixel composition; moved relative-path job and provenance; workspace module resolution; detail geometry; overlap detection and layer diagnostics; alpha clipping; grey-background diagnostics; isolated-layer exposure of occluded white halo with unchanged pale pixels and placements; explicit physical-piece source/pose invariants; valid alternating occlusion; backward-compatible ungrouped repeated sources.');
  fs.rmSync(root,{recursive:true,force:true});
}
main().catch(e=>{console.error(e);process.exitCode=1;});
