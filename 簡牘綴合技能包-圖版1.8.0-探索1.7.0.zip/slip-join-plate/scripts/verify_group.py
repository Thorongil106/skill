#!/usr/bin/env python3
"""Exercise group-completeness and physical-layer invariants using temporary inputs."""
import copy
import json
import tempfile
from pathlib import Path
from check_group import check


def main():
    results = []
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root/'image.bin').write_bytes(b'unmodified source fixture')
        (root/'other.bin').write_bytes(b'a different source fixture')
        (root/'whole.svg').write_text('<svg/>')
        ids = ['pA', 'qB', 'rA', 'sA']
        layers = [dict(id=n, physicalPieceId=n, image='image.bin',
                       transform=dict(x=i*10,y=0,scale=1,rotation=0)) for i,n in enumerate(ids)]
        part = copy.deepcopy(layers[1]);part['id']='qB-plane';layers.append(part)
        baseline = {'pieces': layers}
        plan = {'required_views':['front','back'], 'views':[
            {'id':v,'config':v+'.json','expected_piece_ids':ids} for v in ['front','back']],
            'deliverables':['whole.svg']}

        def run(name, mutate=None, plan_mutate=None, good=False):
            data=copy.deepcopy(baseline);spec=copy.deepcopy(plan)
            if mutate:mutate(data)
            if plan_mutate:plan_mutate(spec)
            (root/'front.json').write_text(json.dumps(data))
            (root/'back.json').write_text(json.dumps(baseline))
            out=check(spec,root)
            assert out['structure_ok'] is good,(name,out)
            results.append(name)

        run('four pieces, crossed source face and consistent partition',good=True)
        run('two-piece result cannot satisfy four-piece request',lambda d:d.update(pieces=d['pieces'][:2]))
        run('wrong source-face declaration',lambda d:d['pieces'][1].update(physicalPieceId='qA'))
        run('same physical piece partition moved',lambda d:d['pieces'][-1]['transform'].update(x=77))
        run('same physical piece uses a different source',lambda d:d['pieces'][-1].update(image='other.bin'))
        run('required reverse view omitted',plan_mutate=lambda p:p.update(views=p['views'][:1]))
        run('declared deliverable absent',plan_mutate=lambda p:p.update(deliverables=['absent.png']))
        run('negative scale rejected',lambda d:d['pieces'][0]['transform'].update(scale=-1))
        run('nonuniform scale field rejected',lambda d:d['pieces'][0]['transform'].update(scaleX=1.2))
    print(json.dumps({'passed':len(results),'cases':results,'image_quality_not_tested':True},indent=2))


if __name__=='__main__':main()
