'use strict';

// Sample each displayed layer over the same small aperture. Alpha, not pixel
// colour, identifies occlusion even if the two pieces have the same ink tone.
async function checkProtectedInk(regions, pieces, ppu, sharp, fragmentSVG, apply) {
  if (!Array.isArray(regions)) throw new Error('protectedInk must be an array');
  const ids = new Set();
  const samples = [];
  for (const region of regions) {
    const owner = pieces.find(piece => piece.id === region?.layerId);
    if (!owner || typeof region.id !== 'string' || !region.id.trim() || ids.has(region.id)) {
      throw new Error('protectedInk needs distinct named regions and existing layer IDs');
    }
    ids.add(region.id);
    if (region.sourceSha256 !== owner.sha256) throw new Error('protectedInk source hash mismatch: ' + region.id);
    if (!Array.isArray(region.points) || !region.points.length) throw new Error('Missing ink points: ' + region.id);
    for (const point of region.points) {
      if (!Array.isArray(point) || point.length !== 2 || !point.every(Number.isFinite) ||
          point[0] < 0 || point[0] >= owner.width || point[1] < 0 || point[1] >= owner.height) {
        throw new Error('Ink point outside native source: ' + region.id);
      }
      samples.push({region: region.id, layerId: owner.id, point, scene: apply(owner.transform, point),
                    ownAlpha: 0, visibleAlpha: 0});
    }
  }
  const aperture = 1 / ppu;
  for (const piece of pieces) {
    const drawing = fragmentSVG(piece, 0);
    for (let start = 0; start < samples.length; start += 256) {
      const batch = samples.slice(start, start + 256);
      const cells = batch.map(({scene: [x,y]}, i) =>
        `<svg x="${i}" width="1" height="1" viewBox="${x-aperture/2} ${y-aperture/2} ${aperture} ${aperture}"><use xlink:href="#piece"/></svg>`);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${batch.length}" height="1"><defs><g id="piece">${drawing}</g></defs>${cells.join('')}</svg>`;
      const alpha = await sharp(Buffer.from(svg)).ensureAlpha().extractChannel('alpha').raw().toBuffer();
      batch.forEach((sample, i) => {
        const owner = pieces.find(p => p.id === sample.layerId);
        const samePiece = piece === owner || (owner.physicalPieceId !== undefined &&
                                              owner.physicalPieceId === piece.physicalPieceId);
        const a = alpha[i] / 255;
        sample.visibleAlpha *= 1-a;
        if (samePiece) {
          sample.ownAlpha += (1-sample.ownAlpha)*a;
          sample.visibleAlpha += a;
        }
      });
    }
  }
  for (const s of samples) {
    if (!s.ownAlpha) s.state = 'outside_own_mask_or_transparent';
    else if (!s.visibleAlpha) s.state = 'covered';
    else if (s.visibleAlpha < 1) s.state = 'partial';
    else s.state = 'visible';
  }
  return {method: 'Layer-alpha contributions at named native-image points. Partial includes a mask edge or source transparency. No ink identification or judgement of fit.',
          apertureCanvasUnits: aperture, samples};
}
module.exports = {checkProtectedInk};
