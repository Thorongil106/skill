#!/usr/bin/env python3
"""Check requested assembly membership and layer consistency, never physical joins."""
import argparse
import sys
import hashlib
import json
import math
from pathlib import Path


def check(plan, root):
    root = Path(root)
    problems, summaries = [], []
    views = plan.get('views', [])
    ids = [v.get('id') for v in views]
    if not views or len(set(ids)) != len(ids) or any(not i for i in ids):
        problems.append({'problem': 'missing_or_duplicate_view_ids'})
    required = plan.get('required_views', [])
    if not required:
        problems.append({'problem': 'required_views_not_declared'})
    for vid in set(required) - set(ids):
        problems.append({'problem': 'required_view_missing', 'view': vid})
    hashes = {}
    for view in views:
        vid = view.get('id')
        local = []
        path = root / view.get('config', '')
        try:
            obj = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError) as error:
            problems.append({'view': vid, 'problem': 'unreadable_config', 'detail': str(error)})
            continue
        expected = view.get('expected_piece_ids', [])
        if not expected or len(set(expected)) != len(expected):
            local.append({'problem': 'missing_or_duplicate_expected_ids'})
        groups, actual = {}, set()
        layers = obj.get('pieces', [])
        if not layers:
            local.append({'problem': 'no_layers'})
        for piece in layers:
            pid = piece.get('physicalPieceId', piece.get('id'))
            actual.add(pid)
            image = piece.get('image')
            if not isinstance(image, str):
                local.append({'problem': 'missing_source', 'piece': pid})
                continue
            source = (path.parent / image).resolve()
            try:
                if source not in hashes:
                    hashes[source] = hashlib.sha256(source.read_bytes()).hexdigest()
                digest = hashes[source]
            except OSError:
                local.append({'problem': 'unreadable_source', 'piece': pid})
                continue
            t = piece.get('transform')
            if not isinstance(t, dict) or piece.get('align') is not None:
                local.append({'problem': 'use_resolved_parameters', 'piece': pid})
                continue
            values = {k: t.get(k, 1 if k == 'scale' else 0) for k in ('x', 'y', 'scale', 'rotation')}
            valid = all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
                        for x in values.values())
            if not valid or values['scale'] <= 0 or set(t) - set(values):
                local.append({'problem': 'not_explicit_similarity', 'piece': pid})
                continue
            signature = (digest, tuple(values[k] for k in ('x', 'y', 'scale', 'rotation')))
            if pid in groups and groups[pid] != signature:
                local.append({'problem': 'same_piece_source_or_transform_conflict', 'piece': pid})
            groups[pid] = signature
        missing = sorted(set(expected) - actual)
        unexpected = sorted(actual - set(expected), key=str)
        if missing:
            local.append({'problem': 'missing_pieces', 'piece_ids': missing})
        if unexpected:
            local.append({'problem': 'unexpected_pieces_or_face_mapping', 'piece_ids': unexpected})
        problems.extend({'view': vid, **p} for p in local)
        summaries.append({'view': vid, 'expected_piece_ids': expected,
                          'actual_piece_ids': sorted(actual, key=str), 'layer_count': len(layers)})
    for value in plan.get('deliverables', []):
        if not (root / value).is_file():
            problems.append({'problem': 'deliverable_missing', 'file': value})
    return {'structure_ok': not problems, 'views': summaries, 'problems': problems,
            'limits': ['Checks declarations, source identity, transforms and files only.',
                       'Does not identify surfaces, verify face hypotheses, measure fit or confirm joins.']}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    path, out = Path(args.plan).resolve(), Path(args.output).resolve()
    plan = json.loads(path.read_text(encoding='utf-8'))
    protected = {path} | {(path.parent / v['config']).resolve() for v in plan.get('views', [])}
    protected |= {(path.parent / p).resolve() for p in plan.get('deliverables', [])}
    for config in list(protected):
        if config == path or not config.is_file() or config.suffix != '.json':
            continue
        try:
            obj = json.loads(config.read_text(encoding='utf-8'))
            protected |= {(config.parent / p['image']).resolve() for p in obj.get('pieces', []) if 'image' in p}
        except (OSError, ValueError):
            pass
    if out in protected:
        raise ValueError('Output must not overwrite the plan, configurations, sources or deliverables.')
    result = check(plan, path.parent)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'structure_ok': result['structure_ok'], 'problem_count': len(result['problems']),
                      'output': str(out)}, ensure_ascii=False))
    raise SystemExit(0 if result['structure_ok'] else 1)


if __name__ == '__main__':
    main()
