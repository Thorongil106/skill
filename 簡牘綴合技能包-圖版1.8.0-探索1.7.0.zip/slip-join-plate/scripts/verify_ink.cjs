'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const {compose, loadSharp} = require('./compose.cjs');

async function main() {
  const sharp = loadSharp(process.argv[2]);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), '殘墨 check '));
  try {
    const a = path.join(dir,'a.png'), b = path.join(dir,'b.png');
    await sharp({create:{width:8,height:8,channels:3,background:'#554444'}}).png().toFile(a);
    const rgba = Buffer.alloc(8*8*4,255);
    rgba[(1*8+1)*4+3] = 0;
    rgba[(1*8+2)*4+3] = 128;
    await sharp(rgba,{raw:{width:8,height:8,channels:4}}).png().toFile(b);
    const sha = crypto.createHash('sha256').update(fs.readFileSync(a)).digest('hex');
    const cfg = {name:'test',pixelsPerUnit:1,margin:0,
      pieces:[
        {id:'a',physicalPieceId:'A',image:'a.png',polygon:[[0,0],[7,0],[7,8],[0,8]]},
        {id:'b',image:'b.png',transform:{x:2}},
        {id:'a-end',physicalPieceId:'A',image:'a.png',polygon:[[5,4],[7,4],[7,6],[5,6]]}
      ],
      protectedInk:[{id:'marks',layerId:'a',sourceSha256:sha,
        points:[[.5,.5],[3.5,1.5],[4.5,1.5],[4.5,3.5],[5.5,5.5],[7.5,7.5]]}]};
    const conf = path.join(dir,'job.json');
    fs.writeFileSync(conf,JSON.stringify(cfg));
    await compose(conf, dir, sharp);
    const m = JSON.parse(fs.readFileSync(path.join(dir,'test-manifest.json')));
    assert.deepEqual(m.inkReview.samples.map(s=>s.state),
      ['visible','visible','partial','covered','visible','outside_own_mask_or_transparent']);
    cfg.pieces[0].transform = cfg.pieces[2].transform = {x:10,y:1,rotation:90,scale:2};
    fs.writeFileSync(conf,JSON.stringify(cfg));
    await compose(conf,dir,sharp,{overwrite:true});
    const moved = JSON.parse(fs.readFileSync(path.join(dir,'test-manifest.json')));
    assert.deepEqual(moved.inkReview.samples[0].scene,[9,2]);
    assert.equal(moved.inkReview.samples[0].state,'covered');
    cfg.protectedInk[0].sourceSha256 = 'old-file';
    fs.writeFileSync(conf,JSON.stringify(cfg));
    await assert.rejects(compose(conf,path.join(dir,'bad'),sharp),/hash mismatch/);
    assert.equal(fs.existsSync(path.join(dir,'bad')),false);
    console.log('PASS: visible, covered, source transparency, mask clipping, alternating layers, transformed coordinates and changed-source rejection.');
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
}
main().catch(err=>{console.error(err);process.exitCode=1;});
