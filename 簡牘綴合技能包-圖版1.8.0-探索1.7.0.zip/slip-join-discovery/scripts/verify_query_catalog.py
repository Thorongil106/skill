#!/usr/bin/env python3
"""Check scope retention, evidence provenance and read-only output behavior."""
import csv
import hashlib
import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from query_catalog import query, recall_group, write_tsv
from plan_xuanquan_scope import GRID_PATH, grid_cells, make_plan, relation


class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.db = self.root / "cards.sqlite"
        self.manifest = self.root / "CATALOG.json"
        self.manifest.write_text(json.dumps({"schema": "xuanquan-evidence-catalog-v1",
            "database": "cards.sqlite", "cards": "cards.jsonl"}))
        self.conn = sqlite3.connect(self.db)
        self.conn.executescript("""
            CREATE TABLE cards(card_id TEXT PRIMARY KEY,label TEXT,scope TEXT,
                identity_status TEXT,trench TEXT,layer TEXT,payload TEXT);
            CREATE TABLE observations(record_id TEXT PRIMARY KEY,source_id TEXT,
                subject TEXT,field TEXT,evidence_status TEXT,value_json TEXT,
                raw_text TEXT,locator_json TEXT,payload TEXT);
            CREATE TABLE card_observations(card_id TEXT,record_id TEXT);
            CREATE TABLE sources(source_id TEXT PRIMARY KEY,name TEXT,volume INTEGER,sha256 TEXT);
            INSERT INTO sources VALUES('source','test source',6,'hash');
        """)
        entries = [
            ("other", "T①:1", "single", "T", "①", {}),
            ("unknown", "T:3", "single", "T", None, {}),
            ("ten", "T②:10", "single", "T", "②", {}),
            ("two", "T②:2", "single", "T", "②", {}),
            ("group", "T②:4AB", "face_group", "T", "②", {"related": ["face"]}),
            ("face", "T②:4A", "face", "T", "②", {"related": ["group"]}),
            ("external", "X②:1", "single", "X", "②", {}),
        ]
        for card_id, label, scope, trench, layer, payload in entries:
            self.conn.execute("INSERT INTO cards VALUES(?,?,?,?,?,?,?)",
                (card_id, label, scope, "documented", trench, layer, json.dumps(payload)))
        self.observation("old", "two", "material", "old", "current_verified",
                         {"catalog_current_status": "superseded"})
        self.observation("current", "two", "material", "new", "current_verified")
        self.observation("dim", "group", "dimensions", {"width": "0.9", "unit": None},
                         "machine_unreviewed")
        self.observation("text", "face", "transcription", "字", "document_transcription")
        self.observation("empty", "unknown", "transcription", "", "document_transcription")
        self.conn.commit()
        self.conn.close()
        self.hash_before = hashlib.sha256(self.db.read_bytes()).hexdigest()

    def observation(self, oid, card, field, value, status, payload=None):
        self.conn.execute("INSERT INTO observations VALUES(?,?,?,?,?,?,?,?,?)",
            (oid, "source", card, field, status, json.dumps(value), "raw", "{}", json.dumps(payload or {})))
        self.conn.execute("INSERT INTO card_observations VALUES(?,?)", (card, oid))

    def test_priority_retains_other_and_unknown_layers(self):
        result = query(self.manifest, "T", "②")
        self.assertEqual(result["record_count"], 6)
        self.assertEqual(result["recall_group_counts"], {
            "same_layer": 4, "other_layer_same_trench": 1, "unknown_layer_same_trench": 1})
        labels = [r["label"] for r in result["records"]]
        self.assertLess(labels.index("T②:2"), labels.index("T②:10"))
        self.assertEqual(labels[-2:], ["T①:1", "T:3"])
        self.assertEqual(hashlib.sha256(self.db.read_bytes()).hexdigest(), self.hash_before)

    def test_other_trench_never_inherits_target_stratum(self):
        result = query(self.manifest, "T", "②", target_trench="X")
        self.assertEqual(result["recall_group_counts"],
                         {"cross_trench_layer_recorded": 5, "cross_trench_layer_unknown": 1})
        self.assertEqual(result["record_count"], 6)
        self.assertEqual(query(self.manifest, "X", "②", target_trench="T")["records"][0]["recall_group"],
                         "cross_trench_layer_recorded")
        same = query(self.manifest, "T", "②", target_trench="Ｔ")
        self.assertEqual(same["recall_group_counts"]["same_layer"], 4)

    def test_scatter_is_never_counted_as_same_layer(self):
        self.assertEqual(recall_group("S", "S"), "scatter_same_trench")
        self.assertEqual(recall_group("①", "S"), "same_trench")
        self.assertEqual(recall_group("S", "②"), "unknown_layer_same_trench")

    def test_group_fields_not_inherited_and_superseded_not_used(self):
        result = query(self.manifest, "T", "②")
        rows = {r["card_id"]: r for r in result["records"]}
        self.assertIn("dimensions", rows["face"]["missing_fields"])
        self.assertEqual(rows["face"]["related_card_ids"], ["group"])
        self.assertEqual(rows["group"]["machine_unreviewed_record_ids"], ["dim"])
        self.assertEqual(rows["unknown"]["empty_value_record_ids"], ["empty"])
        self.assertEqual([o["record_id"] for o in rows["two"]["observations"]], ["current"])
        self.assertEqual(result["superseded_observations_omitted"], 1)
        self.assertEqual(result["sources"]["source"]["sha256"], "hash")

    def test_tsv_contains_all_cards_and_evidence_identity(self):
        result = query(self.manifest, "T", "②")
        path = self.root / "inventory.tsv"
        write_tsv(result, path)
        with path.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f, delimiter="\t"))
        self.assertEqual({r["label"] for r in rows}, {r["label"] for r in result["records"]})
        row = next(r for r in rows if r["label"] == "T②:4AB")
        self.assertEqual(json.loads(row["evidence_refs"])[0]["record_id"], "dim")
        self.assertEqual(json.loads(row["dimensions"])["unit"], None)

    def test_label_subset_and_unknown_request_are_explicit(self):
        result = query(self.manifest, "T", labels=("T②:2", "T②:404"))
        self.assertEqual(result["record_count"], 1)
        self.assertEqual(result["requested_labels_absent"], ["T②:404"])
        self.assertEqual(result["records"][0]["recall_group"], "same_trench")

    def test_portable_inventory_moves_with_its_catalog(self):
        import shutil
        scripts = Path(__file__).resolve().parent
        folder = self.root / "資料 folder"
        folder.mkdir()
        db = folder / self.db.name
        manifest = folder / self.manifest.name
        shutil.copyfile(self.db, db)
        shutil.copyfile(self.manifest, manifest)
        result_file = folder / "結果" / "list.json"
        subprocess.run([sys.executable, str(scripts / "query_catalog.py"),
                        "--catalog", str(manifest), "--trench", "T",
                        "--portable-paths", "--output", str(result_file)], check=True, capture_output=True)
        result = json.loads(result_file.read_text(encoding="utf-8"))
        self.assertEqual(result["path_base"], "inventory_directory")
        self.assertEqual(result["database"], "../cards.sqlite")
        moved = folder.rename(self.root / "新位置 moved")
        inventory = moved / "結果" / "list.json"
        self.assertEqual((inventory.parent / result["catalog_manifest"]).resolve(), (moved / self.manifest.name).resolve())
        reviews = moved / "reviews.json"
        reviews.write_text('{"reviews":[]}', encoding="utf-8")
        command = [sys.executable, str(scripts / "audit_candidates.py"), "--inventory", str(inventory),
                   "--reviews", str(reviews), "--output"]
        report = moved / "report.json"
        subprocess.run(command+[str(report)], cwd=self.root, check=True, capture_output=True)
        self.assertEqual(json.loads(report.read_text(encoding="utf-8"))["selected_card_count"], result["record_count"])
        blocked = subprocess.run(command+[str(moved / db.name)], cwd=self.root, capture_output=True)
        self.assertNotEqual(blocked.returncode, 0)
        self.assertIn(b"must not overwrite", blocked.stderr)
        self.assertEqual(hashlib.sha256((moved / db.name).read_bytes()).hexdigest(), self.hash_before)

    def test_cli_protects_other_catalog_inputs(self):
        dest = self.root / "cards.jsonl"
        dest.write_text("original")
        result = subprocess.run([sys.executable, str(Path(__file__).with_name("query_catalog.py")),
            "--catalog", str(self.manifest), "--trench", "T", "--output", str(dest)],
            capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("must not overwrite", result.stderr)
        self.assertEqual(dest.read_text(), "original")
        self.assertEqual(hashlib.sha256(self.db.read_bytes()).hexdigest(), self.hash_before)


class ExcavationPlanTests(unittest.TestCase):
    def test_public_map_keeps_district_and_actual_adjacency(self):
        cells = grid_cells(json.loads(GRID_PATH.read_text(encoding="utf-8")))
        self.assertEqual(len(cells), 104)
        self.assertEqual(relation(cells, "II:0114", "I:0114"), ("shared_grid_side", 1))
        self.assertEqual(relation(cells, "II:0216", "I:0216"), ("unlocated", None))
        plan = make_plan("Ⅱ90DXT0216")
        self.assertEqual({r["grid_cell"] for r in plan["map_neighbors"]
                          if r["proximity"] == "shared_grid_side"}, {"II:0215"})
        self.assertEqual({r["grid_cell"] for r in plan["map_neighbors"]
                          if r["proximity"] == "shared_grid_corner"}, {"II:0115", "II:0315"})

    def test_explicit_scope_and_unlocated_cards(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with sqlite3.connect(root / "cards.sqlite") as db:
                db.execute("CREATE TABLE cards(trench TEXT)")
                db.executemany("INSERT INTO cards VALUES(?)",
                               [(s,) for s in ("Ⅱ90DXT0216", "Ⅱ90DXT0215", "Ⅰ90DXT0216",
                                               "Ⅱ91DXT0216", "")])
            manifest = root / "CATALOG.json"
            manifest.write_text(json.dumps({"schema": "xuanquan-evidence-catalog-v1",
                                            "database": "cards.sqlite"}))
            strict = make_plan("II90DXT0216", manifest, same_trench_only=True)
            self.assertEqual([r["trench"] for r in strict["catalog_trenches"]], ["Ⅱ90DXT0216"])
            self.assertEqual(strict["map_neighbors"], [])
            full = make_plan("Ⅱ90DXT0216", manifest)
            kinds = {r["trench"]: r["proximity"] for r in full["catalog_trenches"]}
            self.assertEqual(kinds["Ⅱ91DXT0216"], "same_map_cell_other_identifier")
            self.assertEqual(kinds["Ⅱ90DXT0215"], "shared_grid_side")
            self.assertEqual(kinds["Ⅰ90DXT0216"], "unlocated")
            self.assertEqual(kinds[""], "unlocated")


if __name__ == "__main__":
    unittest.main()
