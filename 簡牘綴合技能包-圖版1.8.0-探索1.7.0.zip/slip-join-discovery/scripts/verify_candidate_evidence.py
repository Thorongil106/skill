#!/usr/bin/env python3
"""Check weak image exclusions remain outstanding rather than silently closing a scope."""
import copy
import json
from audit_candidates import audit


def main():
    inventory={'records':[{'card_id':'c1','label':'sample','recall_group':'same_layer'}]}
    base={'target':'test','reviews':[{'card_id':'c1','state':'excluded','reason':'test reason',
                                   'evidence_refs':['source#window']} ]}
    results=[]

    def run(name, row, complete, strict=True):
        out=audit(inventory,{'target':'test','reviews':[row]},require_evidence_scope=strict)
        assert out['accounting_complete'] is complete,(name,out)
        if not complete:assert out['outstanding_count']==1,(name,out)
        results.append(name)

    row=base['reviews'][0]
    run('legacy accounting remains compatible',copy.deepcopy(row),True,False)
    run('new exclusion without provenance is outstanding',copy.deepcopy(row),False)
    weak={**row,'decision_origin':'assistant','decision_basis':['handwriting','spacing'],
          'image_assessment':{'detail_level':'overview','comparable_scale':True,
                              'comparison_windows':['two source faces upper ends']}}
    run('overview cannot close detail-based handwriting rejection',weak,False)
    native=copy.deepcopy(weak);native['image_assessment']['detail_level']='native'
    run('declared native comparable window passes record check',native,True)
    unscaled=copy.deepcopy(native);unscaled['image_assessment']['comparable_scale']=False
    run('independently resized thumbnails do not pass',unscaled,False)
    no_window=copy.deepcopy(native);no_window['image_assessment']['comparison_windows']=[]
    run('native label alone without comparison window is insufficient',no_window,False)
    run('user exclusion keeps its own attribution',{**row,'decision_origin':'user','decision_basis':['user']},True)
    run('source field exclusion does not demand image metadata',
        {**row,'decision_origin':'assistant','decision_basis':['source_field']},True)
    bad=copy.deepcopy(native);bad['image_assessment']='not a record'
    run('malformed evidence metadata fails closed',bad,False)
    print(json.dumps({'passed':len(results),'cases':results,'actual_images_not_assessed':True},indent=2))


if __name__=='__main__':main()
