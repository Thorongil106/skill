#!/usr/bin/env python3
"""Account for candidate review states without assessing images or deciding joins."""
import argparse
import sys
import json
from collections import Counter
from pathlib import Path

STATES = {
    "queued", "needs_source", "needs_native", "hypothesis", "trial_unresolved",
    "supported", "excluded", "out_of_scope", "deferred",
}
UNFINISHED = {"queued", "needs_source", "needs_native", "hypothesis", "trial_unresolved", "deferred"}


def audit(inventory, review_log, group=None, require_evidence_scope=False):
    records = inventory["records"]
    reviews = review_log["reviews"]
    inventory_ids = [r["card_id"] for r in records]
    review_ids = [r["card_id"] for r in reviews]
    duplicate_inventory = sorted(k for k, n in Counter(inventory_ids).items() if n > 1)
    duplicate_reviews = sorted(k for k, n in Counter(review_ids).items() if n > 1)
    available_groups = sorted({r.get("recall_group", "unclassified") for r in records})
    if group is not None and group not in available_groups:
        raise ValueError(f"Unknown or absent group {group!r}; available: {available_groups}")
    selected = [r for r in records if group is None or r.get("recall_group") == group]
    selected_ids = {r["card_id"] for r in selected}
    all_ids = set(inventory_ids)
    by_id = {r["card_id"]: r for r in reviews}
    problems = []
    counts = Counter()
    outstanding = []
    supported = []
    for record in selected:
        card_id = record["card_id"]
        review = by_id.get(card_id)
        identity = {"card_id": card_id, "label": record.get("label"),
                    "recall_group": record.get("recall_group")}
        if review is None:
            counts["unrecorded"] += 1
            outstanding.append({**identity, "state": "unrecorded"})
            continue
        state = review.get("state")
        if state not in STATES:
            counts["invalid_state"] += 1
            problems.append({**identity, "problem": "invalid_state", "value": state})
            outstanding.append({**identity, "state": "invalid_state"})
            continue
        counts[state] += 1
        valid = True
        if require_evidence_scope and state == 'excluded':
            origin = str(review.get('decision_origin') or '').strip()
            basis = review.get('decision_basis')
            if not origin or not isinstance(basis, list) or not basis or not all(
                    isinstance(v, str) and v.strip() for v in basis):
                problems.append({**identity, 'problem': 'missing_decision_origin_or_basis'})
                valid = False
            image_basis = {'handwriting', 'ink', 'spacing', 'grain', 'interface'}
            if (origin == 'assistant' and isinstance(basis, list)
                    and all(isinstance(v, str) for v in basis) and image_basis.intersection(basis)):
                assessment = review.get('image_assessment')
                assessment = assessment if isinstance(assessment, dict) else {}
                windows = assessment.get('comparison_windows')
                if (assessment.get('detail_level') not in {'native', 'original_page'}
                        or assessment.get('comparable_scale') is not True
                        or not isinstance(windows, list) or not windows
                        or not all(isinstance(w, str) and w.strip() for w in windows)):
                    problems.append({**identity, 'problem': 'insufficient_image_evidence_scope'})
                    valid = False
        if state in {"excluded", "out_of_scope", "supported"}:
            refs = review.get("evidence_refs")
            if not str(review.get("reason") or "").strip() or not (
                isinstance(refs, list) and refs and all(isinstance(v, str) and v.strip() for v in refs)
            ):
                problems.append({**identity, "problem": "conclusion_without_reason_or_evidence", "state": state})
                valid = False
        if state == "deferred" and not (
            str(review.get("reason") or "").strip() and str(review.get("next_check") or "").strip()
        ):
            problems.append({**identity, "problem": "deferral_without_reason_or_next_check"})
            valid = False
        if state in UNFINISHED or not valid:
            outstanding.append({**identity, "state": state, "next_check": review.get("next_check")})
        if state == "supported":
            supported.append(identity)
    orphan_ids = sorted(set(review_ids) - all_ids)
    return {
        "target": review_log.get("target"), "direction": review_log.get("direction"),
        "evidence_scope_required": require_evidence_scope,
        "group": group, "available_groups": available_groups,
        "inventory_card_count": len(records), "selected_card_count": len(selected),
        "state_counts": dict(counts),
        "unrecorded_card_ids": sorted(selected_ids - set(review_ids)),
        "duplicate_inventory_ids": duplicate_inventory,
        "duplicate_review_ids": duplicate_reviews,
        "out_of_inventory_review_ids": orphan_ids,
        "record_problems": problems, "outstanding": outstanding,
        "outstanding_count": len(outstanding),
        "supported_records": supported,
        "accounting_complete": not (duplicate_inventory or duplicate_reviews or orphan_ids or problems
                                    or selected_ids - set(review_ids)),
        "limits": [
            "Accounting only: complete records do not mean completed image review or exhausted corpus.",
            "Evidence references and reasons are not independently verified by this tool.",
            "Supported or plausible candidates require handling before claiming no suitable candidate.",
            "Unresolved source coverage and unlinked faces must be assessed outside this inventory.",
            "No automatic permission to expand scope, no joining, no catalog mutation.",
        ],
    }


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--reviews", required=True)
    parser.add_argument("--group")
    parser.add_argument("--output", required=True)
    parser.add_argument("--require-evidence-scope", action='store_true',
                        help='Require provenance/basis for exclusions and native comparable windows for assistant image exclusions.')
    args = parser.parse_args()
    inputs = [Path(args.inventory).resolve(), Path(args.reviews).resolve()]
    output = Path(args.output).resolve()
    if output in inputs:
        raise ValueError("Output must not overwrite input records.")
    # Read first; malformed inputs must not create a report with a false success.
    inventory, reviews = [json.loads(p.read_text(encoding="utf-8")) for p in inputs]
    base = inputs[0].parent if inventory.get("path_base") == "inventory_directory" else Path.cwd()
    protected = {(base / inventory[key]).resolve() for key in ("database", "catalog_manifest")
                 if isinstance(inventory.get(key), str)}
    if output in protected:
        raise ValueError("Output must not overwrite catalog sources.")
    result = audit(inventory, reviews, args.group, args.require_evidence_scope)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "selected_card_count": result["selected_card_count"],
                      "accounting_complete": result["accounting_complete"],
                      "outstanding_count": result["outstanding_count"],
                      "accounting_is_not_scope_exhaustion": True,
                      "state_counts": result["state_counts"]}, ensure_ascii=False))
    if args.require_evidence_scope and not result['accounting_complete']:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
