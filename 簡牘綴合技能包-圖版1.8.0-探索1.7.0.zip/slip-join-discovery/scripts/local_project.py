#!/usr/bin/env python3
"""Register user-selected sources and a card catalog in a portable research project.

Standard library only. Source registration does not extract or verify evidence cards.
Mutating commands for one project should be run sequentially.
"""
import argparse
import sys
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import tempfile

SCHEMA = "slip-research-project-v1"
NOTICE = "請先載入本次研究的圖版、釋文或形制尺寸檔案，以建立資料卡；已有卡庫可直接接入。"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read_project(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema") != SCHEMA:
        raise ValueError("Unknown project schema; inspect it before adapting.")
    return data


def save_project(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         suffix=".tmp", delete=False)
    temp = Path(handle.name)
    try:
        with handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def stored_path(project, file):
    try:
        return Path(os.path.relpath(file, project.parent)).as_posix()
    except ValueError:  # Windows files on different drives need a local absolute binding.
        return str(file)


def resolve_binding(project, value):
    # A foreign Windows path must not be interpreted as a relative POSIX filename.
    if os.name != "nt" and PureWindowsPath(value).is_absolute():
        return None
    if os.name == "nt" and value.startswith("/") and not value.startswith("//"):
        return None
    return (project.parent / value).resolve()


def source_file(project, value):
    file = Path(value).expanduser().resolve(strict=True)
    if not file.is_file() or file == project.resolve():
        raise ValueError("Choose a source file distinct from the project registry.")
    return file


def initialize(project, name):
    if project.exists():
        return read_project(project)
    data = {"schema": SCHEMA, "corpus": name, "sources": [], "catalog": None}
    save_project(project, data)
    return data


def register(project, file, roles):
    data = read_project(project)
    sha = digest(file)
    for row in data["sources"]:
        if row["sha256"] == sha:
            row["path"] = stored_path(project, file)
            row["roles"] = sorted(set(row["roles"]) | set(roles))
            save_project(project, data)
            return row
    row = {"source_id": "sha256-" + sha, "name": file.name,
           "path": stored_path(project, file), "sha256": sha, "roles": sorted(set(roles))}
    data["sources"].append(row)
    save_project(project, data)
    return row


def rebind(project, source_id, file):
    data = read_project(project)
    row = next((r for r in data["sources"] if r["source_id"] == source_id), None)
    if row is None:
        raise ValueError("Source ID is not registered in this project.")
    if digest(file) != row["sha256"]:
        raise ValueError("Content differs. Register a new source and recheck affected locations.")
    row["path"] = stored_path(project, file)
    save_project(project, data)
    return row


def bind_catalog(project, file):
    data = read_project(project)
    data["catalog"] = {"path": stored_path(project, file),
                       "format": file.suffix.lower().lstrip("."),
                       "coverage_status": "read_catalog_coverage_before_search"}
    save_project(project, data)
    return data["catalog"]


def status(project):
    if not project.exists():
        return {"state": "needs_sources", "notice": NOTICE}
    data = read_project(project)
    sources = []
    for row in data["sources"]:
        path = resolve_binding(project, row["path"])
        state = "missing"
        if path is not None and path.is_file():
            state = "available" if digest(path) == row["sha256"] else "changed"
        sources.append({"source_id": row["source_id"], "name": row["name"], "status": state})
    catalog = data.get("catalog")
    catalog_state = "unbound"
    if catalog:
        path = resolve_binding(project, catalog["path"])
        catalog_state = "available" if path is not None and path.is_file() else "missing"
    if not sources and catalog_state == "unbound":
        state = "needs_sources"
    elif any(r["status"] != "available" for r in sources) or catalog_state == "missing":
        state = "needs_rebinding"
    elif catalog_state == "unbound":
        state = "needs_cards"
    else:
        state = "review_catalog_coverage"
    return {"state": state, "corpus": data["corpus"], "sources": sources,
            "catalog_status": catalog_state, "notice": NOTICE if state == "needs_sources" else None,
            "note": "Registration and file checks do not establish card coverage or image review."}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, help="User project registry, e.g. research/project.json")
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init")
    init.add_argument("--corpus", required=True, help="Name identifying this user's material collection")
    add = commands.add_parser("add-source")
    add.add_argument("--file", required=True)
    add.add_argument("--role", action="append", required=True,
                     choices=("plates", "transcription", "materials", "excavation", "other"))
    relink = commands.add_parser("rebind")
    relink.add_argument("--source-id", required=True)
    relink.add_argument("--file", required=True)
    cat = commands.add_parser("bind-catalog")
    cat.add_argument("--file", required=True)
    commands.add_parser("status")
    args = parser.parse_args()
    project = Path(args.project).expanduser().resolve()
    if args.command == "init":
        result = initialize(project, args.corpus)
    elif args.command == "status":
        result = status(project)
    elif args.command == "add-source":
        result = register(project, source_file(project, args.file), args.role)
    elif args.command == "rebind":
        result = rebind(project, args.source_id, source_file(project, args.file))
    else:
        result = bind_catalog(project, source_file(project, args.file))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
