#!/usr/bin/env python3
"""Read a scoped candidate inventory; never OCR, inspect PDFs or mutate the catalog."""
import argparse
import sys
import csv
import hashlib
import json
import re
import sqlite3
import unicodedata
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

FIELDS = ("form", "condition", "dimensions", "material", "transcription", "plate_location")


def natural_key(label):
    """Keep adjacent serial numbers together without altering their identity."""
    return [(1, int(part)) if part.isdigit() else (0, part)
            for part in re.split(r"(\d+)", label)]


def recall_group(layer, priority_layer):
    if layer == "S" and priority_layer == "S":
        return "scatter_same_trench"
    if not layer or layer == "S":
        return "unknown_layer_same_trench"
    if not priority_layer or priority_layer == "S":
        return "same_trench"
    return "same_layer" if layer == priority_layer else "other_layer_same_trench"


def query(manifest_path, trench, priority_layer=None, labels=(), *, target_trench=None):
    cross_trench = (target_trench is not None and
                    unicodedata.normalize("NFKC", target_trench).strip().upper() !=
                    unicodedata.normalize("NFKC", trench).strip().upper())
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema") != "xuanquan-evidence-catalog-v1":
        raise ValueError("Unsupported schema; inspect the actual catalog format before querying.")
    db_path = (manifest_path.parent / manifest["database"]).resolve()
    if not db_path.is_file():
        raise FileNotFoundError(db_path)
    where, params = "c.trench = ?", [trench]
    if labels:
        where += " AND c.label IN (" + ",".join("?" for _ in labels) + ")"
        params.extend(labels)
    conn = sqlite3.connect(db_path.as_uri() + "?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        cards = list(conn.execute(
            "SELECT c.card_id,c.label,c.scope,c.identity_status,c.layer,c.payload "
            "FROM cards c WHERE " + where, params))
        grouped = {r["card_id"]: [] for r in cards}
        omitted_superseded = 0
        sql = ("SELECT c.card_id,o.* FROM cards c "
               "JOIN card_observations co ON co.card_id=c.card_id "
               "JOIN observations o ON o.record_id=co.record_id WHERE " + where)
        for row in conn.execute(sql, params):
            payload = json.loads(row["payload"])
            if payload.get("catalog_current_status") == "superseded":
                omitted_superseded += 1
                continue
            grouped[row["card_id"]].append({
                "record_id": row["record_id"], "field": row["field"],
                "subject": row["subject"],
                "value": json.loads(row["value_json"]),
                "evidence_status": row["evidence_status"],
                "source_id": row["source_id"],
                "locator": json.loads(row["locator_json"]),
                "raw_text": row["raw_text"],
                "verification_scope": payload.get("verification_scope"),
            })
        records = []
        for row in cards:
            card = dict(row)
            payload = json.loads(card.pop("payload"))
            observations = grouped[row["card_id"]]
            present = {o["field"] for o in observations}
            if cross_trench:
                group = "cross_trench_layer_recorded" if row["layer"] not in (None, "", "S") else "cross_trench_layer_unknown"
            else:
                group = recall_group(row["layer"], priority_layer)
            records.append({
                **card,
                "recall_group": group,
                "base_label": payload.get("base_label"),
                "members": payload.get("members", []),
                "related_card_ids": payload.get("related", []),
                "excavation_basis": payload.get("excavation_basis"),
                "observations": observations,
                "missing_fields": [f for f in FIELDS if f not in present],
                "empty_value_record_ids": [o["record_id"] for o in observations
                                           if o["value"] in (None, "", [], {})],
                "machine_unreviewed_record_ids": [o["record_id"] for o in observations
                                                   if o["evidence_status"] == "machine_unreviewed"],
                "screening_status": "not_screened_by_this_tool",
            })
        order = {"same_layer": 0, "scatter_same_trench": 0, "same_trench": 1,
                 "other_layer_same_trench": 1, "unknown_layer_same_trench": 2,
                 "cross_trench_layer_recorded": 1, "cross_trench_layer_unknown": 2}
        records.sort(key=lambda r: (order[r["recall_group"]],
                                    natural_key(r["label"])))
        source_ids = {o["source_id"] for r in records for o in r["observations"]
                      if o["source_id"]}
        sources = {r["source_id"]: dict(r) for r in conn.execute(
            "SELECT source_id,name,volume,sha256 FROM sources") if r["source_id"] in source_ids}
    finally:
        conn.close()
    found = {r["label"] for r in records}
    return {
        "catalog_manifest": str(manifest_path), "database": str(db_path),
        "catalog_manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "database_mtime_ns": db_path.stat().st_mtime_ns,
        "queried_at": datetime.now(timezone.utc).isoformat(),
        "query": {"trench": trench, "priority_layer": priority_layer,
                  **({"target_trench": target_trench} if target_trench is not None else {}),
                  "labels": list(labels), "layer_is_hard_filter": False},
        "record_count": len(records),
        "count_unit": "catalog_cards_not_physical_artifacts",
        "layer_counts": dict(Counter(r["layer"] for r in records)),
        "recall_group_counts": dict(Counter(r["recall_group"] for r in records)),
        "scope_counts": dict(Counter(r["scope"] for r in records)),
        "missing_field_counts": dict(Counter(f for r in records for f in r["missing_fields"])),
        "requested_labels_absent": [lab for lab in labels if lab not in found],
        "superseded_observations_omitted": omitted_superseded,
        "sources": sources,
        "limits": ["Database scope only; missing cards or fields are not physical exclusion.",
                   "Material, dimensions and text are not hard-filtered by this tool.",
                   "Priority layer changes order and group labels only; other layers remain in the inventory.",
                   "S denotes scattered slips; matching S is a catalog group, not a shared stratum.",
                   "Groups, faces and combined cards are retained; related-card fields are not inherited.",
                   "missing_fields means no active observation; empty values are reported separately.",
                   "Field presence is not verification; empty and unreviewed values need assessment.",
                   "No OCR, raw-page fallback, image assessment or joining performed."],
        "records": records,
    }


def write_tsv(result, output):
    """One row per card; values retain alternatives, evidence IDs point into JSON."""
    columns = ("card_id", "recall_group", "label", "scope", "layer", "base_label",
               *FIELDS, "missing_fields", "empty_value_record_ids",
               "machine_unreviewed_record_ids", "evidence_refs", "source_ids",
               "members", "related_card_ids", "screening_status")
    with output.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for record in result["records"]:
            row = {key: record[key] for key in columns if key in record}
            observations = [o for o in record["observations"] if o["field"] in FIELDS]
            for field in FIELDS:
                # No preferred reading is inferred from frequency or date.
                values = list(dict.fromkeys(json.dumps(o["value"], ensure_ascii=False,
                                                        sort_keys=True)
                                            for o in observations if o["field"] == field))
                row[field] = " | ".join(values)
            row["evidence_refs"] = [{"field": o["field"], "record_id": o["record_id"],
                                     "evidence_status": o["evidence_status"],
                                     "source_id": o["source_id"]} for o in observations]
            row["source_ids"] = sorted({o["source_id"] for o in observations if o["source_id"]})
            writer.writerow({key: json.dumps(value, ensure_ascii=False, separators=(",", ":"))
                             if isinstance(value, (list, dict)) else value
                             for key, value in row.items()})


def protected_inputs(manifest_path):
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    keys = ("database", "browser", "cards", "observations", "sources", "unresolved",
            "raw_pages", "coverage", "guide", "coverage_audit",
            "trench_0216_report", "volume6_report")
    return {manifest_path} | {(manifest_path.parent / manifest[key]).resolve()
                             for key in keys if isinstance(manifest.get(key), str)}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--catalog", required=True)
    p.add_argument("--trench", required=True)
    p.add_argument("--priority-layer")
    p.add_argument("--target-trench", help="Target fragment’s complete trench key. Other trenches keep their own strata; matching layer codes do not imply correlation.")
    p.add_argument("--label", action="append", default=[])
    p.add_argument("--output", required=True)
    p.add_argument("--portable-paths", action="store_true",
                   help="Store catalog and database paths relative to the output inventory where possible.")
    p.add_argument("--tsv-output", help="Optional compact audit table; all queried cards remain included.")
    a = p.parse_args()
    result = query(a.catalog, a.trench, a.priority_layer, a.label, target_trench=a.target_trench)
    output = Path(a.output).resolve()
    tsv_output = Path(a.tsv_output).resolve() if a.tsv_output else None
    if {output, tsv_output} & protected_inputs(a.catalog):
        raise ValueError("Output must not overwrite catalog inputs.")
    if tsv_output == output:
        raise ValueError("JSON and TSV outputs must have different paths.")
    if a.portable_paths:
        from local_project import stored_path
        for key in ("catalog_manifest", "database"):
            result[key] = stored_path(output, Path(result[key]))
        result["path_base"] = "inventory_directory"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if tsv_output:
        tsv_output.parent.mkdir(parents=True, exist_ok=True)
        write_tsv(result, tsv_output)
    print(json.dumps({"output": str(output), "record_count": result["record_count"],
                      "layer_counts": result["layer_counts"],
                      "recall_group_counts": result["recall_group_counts"],
                      "tsv_output": str(tsv_output) if tsv_output else None,
                      "requested_labels_absent": result["requested_labels_absent"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
