#!/usr/bin/env python3
"""List published Xuanquan grid neighbors and, optionally, available catalog trench keys."""
import argparse
import sys
import json
import re
import sqlite3
import unicodedata
from contextlib import closing
from pathlib import Path

GRID_PATH = Path(__file__).resolve().parents[1] / "references" / "xuanquan-grid.json"
FORMAT = re.compile(r"(VI|IV|III|II|I|V)(?:\d{2}DXT|[\s:]*T?)(\d{4})")
PRIORITY = (
    "target_trench", "same_map_cell_other_identifier", "shared_grid_side",
    "shared_grid_corner", "other_same_district", "other_district", "unlocated",
)


def normalized_identifier(trench):
    return unicodedata.normalize("NFKC", trench or "").strip().upper()


def map_key(trench):
    match = FORMAT.fullmatch(normalized_identifier(trench))
    return ":".join(match.groups()) if match else None


def grid_cells(document):
    cells = {}
    for district, data in document["districts"].items():
        for code in data["cells"].split():
            column, row = int(code[:2]), int(code[2:])
            x = 1 - column if data["side"] == "left" else column
            cells[f"{district}:{code}"] = (x, row)
    if len(set(cells.values())) != len(cells):
        raise ValueError("Two published grid cells share coordinates.")
    return cells


def relation(cells, target, candidate):
    if target not in cells or candidate not in cells:
        return "unlocated", None
    x1, y1 = cells[target]
    x2, y2 = cells[candidate]
    dx, dy = abs(x2 - x1), abs(y2 - y1)
    distance = dx + dy
    if distance == 0:
        return "same_map_cell_other_identifier", 0
    if distance == 1:
        return "shared_grid_side", distance
    if dx == dy == 1:
        return "shared_grid_corner", distance
    if target.split(":")[0] == candidate.split(":")[0]:
        return "other_same_district", distance
    return "other_district", distance


def catalog_trenches(manifest_path):
    path = Path(manifest_path).resolve()
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest.get("schema") != "xuanquan-evidence-catalog-v1":
        raise ValueError("Unsupported evidence catalog schema.")
    db = (path.parent / manifest["database"]).resolve()
    with closing(sqlite3.connect(db.as_uri() + "?mode=ro", uri=True)) as conn:
        return conn.execute("SELECT trench, COUNT(*) FROM cards GROUP BY trench").fetchall()


def make_plan(trench, catalog=None, same_trench_only=False, grid_path=GRID_PATH):
    document = json.loads(grid_path.read_text(encoding="utf-8"))
    cells = grid_cells(document)
    target = map_key(trench)
    rows = []
    if catalog:
        for key, count in catalog_trenches(catalog):
            is_target = normalized_identifier(key) == normalized_identifier(trench)
            if same_trench_only and not is_target:
                continue
            location = map_key(key or "")
            proximity, distance = relation(cells, target, location)
            if is_target:
                proximity, distance = "target_trench", 0 if target in cells else None
            rows.append({
                "trench": key, "card_count": count, "proximity": proximity,
                "grid_cell": location if location in cells else None,
                "grid_steps": distance,
            })
    neighbors = []
    if target in cells and not same_trench_only:
        for cell in cells:
            if cell == target:
                continue
            proximity, distance = relation(cells, target, cell)
            neighbors.append({"grid_cell": cell, "proximity": proximity, "grid_steps": distance})
    order = PRIORITY.index
    rows.sort(key=lambda r: (order(r["proximity"]), r["grid_steps"] or 0, r["trench"] or ""))
    neighbors.sort(key=lambda r: (order(r["proximity"]), r["grid_steps"], r["grid_cell"]))
    return {
        "target_trench": trench,
        "target_grid_cell": target if target in cells else None,
        "same_trench_only": same_trench_only,
        "grid_source": document["source"],
        "map_coverage": document["scope"],
        "map_neighbors": neighbors,
        "catalog_trenches": rows,
        "limits": [
            "Planning only. Query each permitted complete trench key separately.",
            "Grid proximity does not correlate strata, prove a common deposit, or exclude joins.",
            "Same-map-cell identifiers from different campaigns require source reconciliation.",
            "Unlocated entries require a source check and remain unknown.",
            "Use confirmed field-record relationships to revise the cross-trench order.",
        ],
    }


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trench", required=True, help="Map key with area or full catalog trench key.")
    parser.add_argument("--catalog", help="Optional evidence catalog manifest.")
    parser.add_argument("--same-trench-only", action="store_true")
    args = parser.parse_args()
    result = make_plan(args.trench, args.catalog, args.same_trench_only)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
