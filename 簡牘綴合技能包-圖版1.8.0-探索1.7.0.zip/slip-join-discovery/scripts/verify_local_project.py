#!/usr/bin/env python3
"""Exercise portable source identity and onboarding states using synthetic files."""
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from local_project import (bind_catalog, initialize, read_project, rebind, register,
                           resolve_binding, source_file, status)


class LocalProjectTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.work = self.root / '甲地 研究'
        self.project = self.work / 'research' / 'project.json'
        self.book = self.work / '原始資料' / '釋文.txt'
        self.book.parent.mkdir(parents=True)
        self.book.write_text('測試號1\n原釋', encoding='utf-8')

    def start(self):
        initialize(self.project, '測試材料')
        return register(self.project, self.book, ['transcription'])

    def test_initial_sources_are_distinct_from_cards(self):
        self.assertEqual(status(self.project)['state'], 'needs_sources')
        initialize(self.project, '測試材料')
        self.assertEqual(status(self.project)['state'], 'needs_sources')
        self.start()
        self.assertEqual(status(self.project)['state'], 'needs_cards')
        cards = self.project.parent / 'cards.jsonl'
        cards.write_text('{}\n', encoding='utf-8')
        bind_catalog(self.project, cards)
        self.assertEqual(status(self.project)['state'], 'review_catalog_coverage')
        # Binding an empty or incomplete card file cannot imply complete coverage.
        self.assertEqual(read_project(self.project)['catalog']['coverage_status'],
                         'read_catalog_coverage_before_search')

    def test_moving_project_preserves_source_id_and_relative_paths(self):
        row = self.start()
        before = self.book.read_bytes()
        self.assertFalse(Path(row['path']).is_absolute())
        moved = self.root / '乙地 搬遷'
        shutil.move(self.work, moved)
        project = moved / 'research' / 'project.json'
        current = status(project)
        self.assertEqual(current['sources'][0]['status'], 'available')
        self.assertEqual(current['sources'][0]['source_id'], row['source_id'])
        self.assertEqual((moved / '原始資料' / '釋文.txt').read_bytes(), before)

    def test_rebind_checks_content_and_preserves_registry_on_failure(self):
        row = self.start()
        new = self.root / '外置 書庫' / self.book.name
        new.parent.mkdir()
        shutil.move(self.book, new)
        self.assertEqual(status(self.project)['state'], 'needs_rebinding')
        rebind(self.project, row['source_id'], new)
        self.assertEqual(status(self.project)['sources'][0]['status'], 'available')
        wrong = self.root / '另一版本.txt'
        wrong.write_text('另一個文本', encoding='utf-8')
        saved = self.project.read_bytes()
        with self.assertRaisesRegex(ValueError, 'Content differs'):
            rebind(self.project, row['source_id'], wrong)
        self.assertEqual(self.project.read_bytes(), saved)
        new.write_text('已被修改', encoding='utf-8')
        self.assertEqual(status(self.project)['sources'][0]['status'], 'changed')

    def test_duplicate_content_and_existing_project_are_reused(self):
        first = self.start()
        duplicate = self.root / '複本.txt'
        shutil.copyfile(self.book, duplicate)
        second = register(self.project, duplicate, ['materials'])
        self.assertEqual(first['source_id'], second['source_id'])
        data = initialize(self.project, '不應覆蓋的名稱')
        self.assertEqual(data['corpus'], '測試材料')
        self.assertEqual(len(data['sources']), 1)
        self.assertEqual(data['sources'][0]['roles'], ['materials', 'transcription'])
        with self.assertRaises(ValueError):
            source_file(self.project, self.project)

    def test_cli_runs_after_tool_and_user_files_move_independently(self):
        tool = self.root / '另一設備 技能' / 'local_project.py'
        tool.parent.mkdir()
        shutil.copyfile(Path(__file__).with_name('local_project.py'), tool)
        command = [sys.executable, str(tool), '--project', 'research/project.json']
        subprocess.run(command + ['init', '--corpus', '新材料'], cwd=self.work,
                       check=True, capture_output=True)
        subprocess.run(command + ['add-source', '--file', '原始資料/釋文.txt',
                                  '--role', 'transcription'], cwd=self.work,
                       check=True, capture_output=True)
        result = subprocess.run(command + ['status'], cwd=self.work,
                                check=True, capture_output=True, encoding="utf-8")
        report = json.loads(result.stdout)
        self.assertEqual(report['state'], 'needs_cards')
        self.assertEqual(report['sources'][0]['status'], 'available')

    def test_missing_card_entry_and_foreign_path_are_reported(self):
        self.start()
        catalog = self.root / 'CATALOG.json'
        catalog.write_text('{}', encoding='utf-8')
        bind_catalog(self.project, catalog)
        catalog.unlink()
        self.assertEqual(status(self.project)['catalog_status'], 'missing')
        import os
        if os.name != 'nt':
            self.assertIsNone(resolve_binding(self.project, r'D:\research\book.pdf'))
        self.assertEqual(resolve_binding(self.project, '../原始資料/釋文.txt'), self.book)


if __name__ == '__main__':
    unittest.main()
